extends CharacterBody2D

@export var SPEED = 850.0
@export var JUMP_VELOCITY = -700.0
@export var direction = 0
@export var gravity = 2500.0
#var jumps = 2

#const momentum_multiplier = 3.0
#const min_launch_speed = 450.0
#const max_launch_speed = 1200.0

var anchor_spawned: bool = false

@onready var anim = $AnimatedSprite2D
@onready var tether_line: Line2D = $TetherLine
@onready var anchor = $Anchor
@onready var jump_sound: AudioStreamPlayer2D = $JumpSound
@onready var teleport_sound: AudioStreamPlayer2D = $Teleport

	
func _ready() -> void:
	tether_line.visible = false
	anchor.visible = false

func _process(delta: float) -> void:
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		if collision.get_collider().is_in_group("obstacles"):
			respawn()
			

func _physics_process(delta: float) -> void:
	
			
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		
			# Spawn or bounce to tether
	if Input.is_action_just_pressed("anchor"):
		if not anchor_spawned:
			spawn_anchor()
		else:
			start_teleport()
			teleport_sound.play()
		

	# Handle jump.
	if Input.is_action_just_pressed("jump"):
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
			jump_sound.play()
			
	if Input.is_action_just_pressed("respawn"):
		respawn()

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	direction = Input.get_axis("left", "right")
	if direction > 0:
		anim.scale.x = 3
	elif direction < 0:
		anim.scale.x = -3
		
	if direction:
		velocity.x = direction * SPEED
	else:
		var friction = 0.2 if is_on_floor() else 0.08
		velocity.x = lerp(velocity.x, 0.0, friction)
		
		#velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	update_animation()
	update_tether()
	
	
func update_animation():
	if direction != 0:
		anim.play("walk")
		
func spawn_anchor():
	anchor.position = global_position
	anchor_spawned = true
	anchor.visible = true
	
func update_tether():
	if anchor_spawned:
		tether_line.visible = true
		tether_line.clear_points()
		tether_line.add_point(anchor.global_position)
		tether_line.add_point(global_position)
	else: 
		tether_line.visible = false
		tether_line.clear_points()
		
func start_teleport() -> void:
	remove_anchor()
	
	var move_dir = velocity.normalized() #get direction of motion
	
	global_position = anchor.global_position

	#var boosted_speed = clamp(velocity.length() * momentum_multiplier, min_launch_speed, max_launch_speed)
	var boosted_speed = 1000
	velocity = move_dir * boosted_speed
	
func respawn() -> void:
	global_position = Vector2(0, 275)
	remove_anchor()
	
func remove_anchor() -> void:
	anchor_spawned = false
	anchor.visible = false
	tether_line.visible = false
	
	
	
