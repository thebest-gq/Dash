extends Node

var time_elapsed: float = 0.0
var is_running: bool = false

func _process(delta: float) -> void:
	if is_running:
		time_elapsed += delta

func start_timer() -> void:
	time_elapsed = 0.0
	is_running = true

func stop_timer() -> void:
	is_running = false

func get_formatted_time() -> String:
	var minutes: int = int(time_elapsed) / 60
	var seconds: int = int(time_elapsed) % 60
	var milliseconds: int = int((time_elapsed - int(time_elapsed)) * 100)
	return "%02d:%02d.%02d" % [minutes, seconds, milliseconds]
